package com.example.prueba01.tema01

fun main(){

    println("Hola clase")

    /** variables numericas
     *
     */

    // variables numericas

    // int -2,147,483,647 a 2,147,483,647
    val intEjemplo1: Int = 10
    val intEjemplo2: Int = -3

    //suma
    print("Suma ")
    println(intEjemplo1 + intEjemplo2)

    //resta
    print("Resta ")
    println(intEjemplo1 - intEjemplo2)

    //multiplicacion
    print("Multiplicacion ")
    println(intEjemplo1 * intEjemplo2)

    //division
    print("Division ")
    println(intEjemplo1 / intEjemplo2)

    //modulo
    print("Modulo ")
    println(intEjemplo1 % intEjemplo2)

    //concatenar
    var nombre = "Nataniel"
    println("Hola soy $nombre")


    //Long -9,223,372,036,854,775,808 \a 9,223,372,036,854,775,807
    val longEjemplo1: Long = 30
    val longEjemplo2: Long = 40

    //Floot
    val floatEjemplo1: Float = 40.4f
    val floatEjemplo2: Float = 21.11f

    //Double
    val doubleEjemplo1: Double = 2443.343434
    val doubleEjemplo2: Double = 2443.34343

    /** variables alfanumericas
     *
     */

    //char
    val charEjemplo1: Char = 'a'
    val charEjemplo2: Char = '@'

    //String
    val stringEjemplo1: String = "Hola soy nata"
    val stringEjemplo2: String = "Adios"

    /** variables booleanas
     *
     */

    //boleean
    val booleanEjemplo1: Boolean = true
    val booleanEjemplo2: Boolean = false




}