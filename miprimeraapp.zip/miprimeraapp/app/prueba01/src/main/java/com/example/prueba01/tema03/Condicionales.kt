package com.example.prueba01.tema03

fun main() {
    ifBasico()
    ifAnidado()
    ifBoolean()
    ifInt()
    ifMultiple()
    ifMultipleOr()
}

fun ifMultipleOr(){
    var animal = "perro"

    // || significa o
    if (animal == "gato" || animal == "perro"){
        println("Es un mamifero")
    }else{
        println("No es un mamifero")
    }
}

fun ifMultiple(){
    var age = 18
    var permiso = true

    if (age >= 18 && permiso == true){
        println("Es mayor de edad, puebes beber")
    }else{
        println("Es menor de edad")
    }
}

fun ifInt(){
    var age = 18

    if (age >= 18){
        println("Es mayor de edad, puebes beber")
    }else{
        println("Es menor de edad")
    }
}

//if boolean
fun ifBoolean(){
    var soyFeliz: Boolean = true

    // caundo es verdadero el valor pasa igual
    //cuando es falso el valor requiere signo de ! de admiracion
    if (soyFeliz){
        println("Estoy feliz")
    }else{
        println("Estoy triste")
    }
}

//if anidado
fun ifAnidado(){
    val animal = "gato"

    if (animal == "leon"){
        println("Es un leon")
    } else if (animal == "gato"){
        println("Es un gato")
    } else if (animal == "oso"){
        println("Es un oso")
    } else {
        println("Es un animal desconocido")
    }

}


fun ifBasico(){
    val apellido = "Janacua"

    // = igualando
    // == comparando
    // === identicos

    if (apellido == "Janacua"){
        println("El apellido es: $apellido")
    }else{
        println("El apellido no es $apellido")
    }

}

