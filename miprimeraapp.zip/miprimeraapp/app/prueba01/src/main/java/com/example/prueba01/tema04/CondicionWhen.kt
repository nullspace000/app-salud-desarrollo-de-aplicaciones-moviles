package com.example.prueba01.tema04

fun main(){
    obtenerMes(8)
    obtenerTrimeste(5)
    obtenerSemestre(3)
}


fun obtenerSemestre(mes: Int){
    when (mes){
        in 1..6 -> println("Primer semestre")
        in 7..12 -> println("Segundo semestre")
        else -> println("Mes no valido")

    }
}

fun obtenerTrimeste(mes: Int){
    when (mes){
        1, 2, 3 -> println("Primer trimestre")
        4, 5, 6 -> println("Segundo trimestre")
        7, 8, 9 -> println("Tercer trimestre")
        10, 11, 12 -> println("Cuarto trimestre")
        else -> println("Mes no valido")
    }
}

fun obtenerMes(mes: Int){

    when(mes){
        1 -> println("Enero")
        2 -> println("Febrero")
        3 -> println("Marzo")
        4 -> println("Abril")
        5 -> println("Mayo")
        6 -> println("Junio")
        7 -> println("Julio")
        8 -> println("Agosto")
        9 -> println("Septiembre")
        10 -> println("Octubre")
        11 -> println("Noviembre")
        12 -> println("Diciembre")
    }


    if (mes == 1){
        println("Enero")
    }else if (mes == 2){
        println("Febrero")
    }else if (mes == 3){
        println("Marzo")
    }else if (mes == 4){
        println("Abril")
    } else if (mes == 5){
        println("Mayo")
    }else if (mes == 6){
        println("Junio")
    } else if (mes == 7){
        println("Julio")
    }else if (mes == 8){
        println("Agosto")
    } else if (mes == 9){
        println("Septiembre")
    }else if (mes == 10){
        println("Octubre")
    } else if (mes == 11){
        println("Noviembre")
    } else if (mes == 12){
        println("Diciembre")
    }

}



