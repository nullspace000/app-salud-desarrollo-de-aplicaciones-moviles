package com.example.prueba01.tema02

fun main(){
    println("Hola clase")
    variablesNumericas()
    variablesAlfanumericas()
    miNombre("Natanael")
    mostrarSuma(5,9)
    println(mostrarResta(89, 9))
    println(restaCool(89, 9))
}

//resta cool
fun restaCool(num1: Int, num2: Int): Int = num1 - num2


//mostrar la resta
fun mostrarResta(num1: Int, num2: Int): Int{
    var resultado = num1 - num2
    println("la resta de los valores es igual a $resultado")
    return resultado
}

//mostrar suma
fun mostrarSuma(num1: Int, num2: Int){
    var resultado = num1 + num2
    println("la suma de los valores es igual a $resultado")
}

//funcion con parametros
fun miNombre(nombre: String){
    println("Hola mi nombre es $nombre")

}

fun variablesAlfanumericas(){

    /** variables alfanumericas
     *
     */

    //char
    val charEjemplo1: Char = 'a'
    val charEjemplo2: Char = '@'

    //String
    val stringEjemplo1: String = "Hola soy nata"
    val stringEjemplo2: String = "Adios"
    println("char $charEjemplo1")
    println("String $stringEjemplo1")

    }

fun variablesNumericas(){

    // int -2,147,483,647 a 2,147,483,647
    val intEjemplo1: Int = 10
    val intEjemplo2: Int = -3
    println("entero $intEjemplo1")

    //Long -9,223,372,036,854,775,808 \a 9,223,372,036,854,775,807
    val longEjemplo1: Long = 30
    val longEjemplo2: Long = 40
    println("long $longEjemplo1")

    //Floot
    val floatEjemplo1: Float = 40.4f
    val floatEjemplo2: Float = 21.11f
    println("float $floatEjemplo1")

    //Double
    val doubleEjemplo1: Double = 2443.343434
    val doubleEjemplo2: Double = 2443.34343
    println("double $doubleEjemplo1")


}