package com.example.prueba01

class prueba01 {
}